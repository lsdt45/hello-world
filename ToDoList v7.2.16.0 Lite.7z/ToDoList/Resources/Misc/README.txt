2016-09-18 : Tony Gravagno

The .xsd schema file was generated off of TdlSchema.xml. This XML file is just a renamed TdlSchema.tdl where an attempt was made to make use of all possible ToDoList features. Features not used will not be reflected in the schema, so it's possible that the schema is incomplete. However, these files have been used for the last several months in testing the new ToDoListLib.NET (not recently updated but not forgotten either: https://ToDoListLibDotNet.codeplex.com/), and no functionality seems to be missing. So unless someone says otherwise it can be assumed that this schema is complete and accurately defines ToDoList v6.9 .tdl files.

If an error is found in the schema, or a function has been misused in the XML, please post a note to the project issue tracker.

Thanks.
