﻿======================================================================
                   FastCopy  ver3.61                   2018/11/08
                                                 SHIROUZU Hiroaki
                                                 FastCopy Lab, LLC.
                   FastCopy-M branch                   2018/12/11
                                                 Mapaler
======================================================================

	FastCopy is the Fastest Copy/Delete Software on Windows.

	It can copy/delete unicode and over MAX_PATH(260byte) pathname files.

	It always run by multi-threading.

	It don't use MFC, it is compact and don't requre mfcxx.dll.

	FastCopy is GPLv3 license, you can modify and use under GPLv3
	
	FastCopy-M feature :
	More complete multilanguage supports.

	Support use http url to replace "chm" help files.

License:
	-------------------------------------------------------------------------
	 FastCopy ver3.x
	 Copyright(C) 2004-2018 SHIROUZU Hiroaki All rights reserved.
	 Copyright(C) 2018 FastCopy Lab, LLC. All rights reserved.

	 This program is free software. You can redistribute it and/or modify
	 it under the GNU General Public License version 3.

	 more details: license-gpl3.txt
	-------------------------------------------------------------------------

	xxHash library Copyright (C) 2012-2016 Mr.Yann Collet, All rights reserved.
	  more details: external/xxhash/LICENSE

Usage：
	Please see fastcopy_eng.htm

Build:
	VS2017 or later

