If you add any file into Ec Menu v1.5 Files folder it will be automatically copied to the following path:
%ProgramFiles%\Easy Context Menu\Files\
after adding any portable Application in this folder you can add it in to the Ec menu list with using List Editor
nircmd is just an exapmle , of course we can add any application with drag and drop it on the Easy context menu interface 
but if we do that portable program will not work in the Usb stick that is the reason why we should add the program
in File folder firs

Items.ini : contain context menu interface's list
EcMenu.ini : contain some setting and Language files
